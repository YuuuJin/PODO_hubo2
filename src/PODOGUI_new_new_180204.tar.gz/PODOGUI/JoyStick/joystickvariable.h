#ifndef JOYSTICKVARIABLE_H
#define JOYSTICKVARIABLE_H

#include <iostream>
#include <math.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/joystick.h>
#include <pthread.h>

#include <QVector>
#include <QString>

//char	BUTTON_A, BUTTON_B, BUTTON_X, BUTTON_Y, BUTTON_LT, BUTTON_RT;
//char	BUTTON_LB, BUTTON_RB, BUTTON_BACK, BUTTON_START, BUTTON_LJOG, BUTTON_RJOG;
//char	READY_BTN_A, READY_BTN_B, READY_BTN_X, READY_BTN_Y, READY_BTN_LT, READY_BTN_RT;
//char	READY_BTN_LB, READY_BTN_RB, READY_BTN_BACK, READY_BTN_START, READY_BTN_LJOG, READY_BTN_RJOG;

//int		AXIS_LJOG_RL, AXIS_LJOG_UD;
//int		AXIS_RJOG_RL, AXIS_RJOG_UD;
//int		AXIS_ARW_RL, AXIS_ARW_UD;

//int		PREV_LJOG_RL, PREV_LJOG_UD;
//int		PREV_RJOG_RL, PREV_RJOG_UD;
//int		PREV_ARW_RL, PREV_ARW_UD;

//int		SPEED_LJOG_RL, SPEED_LJOG_UD;
//int		SPEED_RJOG_RL, SPEED_RJOG_UD;
//int		SPEED_ARW_RL, SPEED_ARW_UD;


#endif // JOYSTICKVARIABLE_H
