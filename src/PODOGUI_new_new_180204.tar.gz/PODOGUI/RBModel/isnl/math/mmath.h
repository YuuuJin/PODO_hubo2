#ifndef __MYLIB_MATH_MMATH__
#define __MYLIB_MATH_MMATH__
#include <isnl/base/mathbase.h>

#ifndef PI
#define	PI				 3.1415927f
#endif
#ifndef PIx2
#define	PIx2			 6.2831853f
#endif
#ifndef R2D
#define R2D				57.2957802f
#endif
#ifndef D2R
#define D2R				 0.0174533f
#endif





#endif
