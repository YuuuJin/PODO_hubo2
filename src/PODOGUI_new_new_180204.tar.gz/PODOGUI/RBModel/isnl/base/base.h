#ifndef _MYLIB_BASE_H_
#define _MYLIB_BASE_H_

#include "base/grammar.h"
#include "base/exceptiondef.h"
#include "base/array.h"

#endif