#ifndef _MYLIB_GRAMMAR_H_
#define _MYLIB_GRAMMAR_H_


#define lengthof(x) sizeof(x)/sizeof(x[0])
#define elif else if



#endif