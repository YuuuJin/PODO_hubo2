#ifndef _MYLIB_STRING_
#define _MYLIB_STRING_
#include <string>
#include <string.h>

namespace isnl{
typedef std::string string;

}


#endif
